import { useEffect, useMemo, useState } from "react"
import {
  AlertCircle,
  ArrowLeft,
  Car,
  CheckCircle2,
  ChevronRight,
  Clock3,
  MapPin,
  Navigation,
  ParkingSquare,
  QrCode,
  Search,
  Sparkles,
  Timer,
  X,
} from "lucide-react"

import Header from "../components/Header"
import StationCard from "../components/StationCard"
import BottomNav from "../components/BottomNav"
import LocationSelector from "../components/LocationSelector"

import { stations } from "../data/stations"
import { locationData } from "../data/locationData"
import { QRCodeSVG } from "qrcode.react"

function Home() {
  // ================================
  // STATE
  // ================================

const [selectedState, setSelectedState] =
  useState("")

const [selectedCity, setSelectedCity] =
  useState("")

  useState("")

const [selectedLocationStation, setSelectedLocationStation] =
  useState("")
  
  const [search, setSearch] = useState("")
  const [activeNav, setActiveNav] = useState("home")

  const [locationEnabled, setLocationEnabled] =
    useState(false)

  const [userLocation, setUserLocation] =
    useState(null)

  const [message, setMessage] = useState("")

  const [selectedStation, setSelectedStation] =
    useState(null)

  const [selectedSlot, setSelectedSlot] =
    useState(null)

  const [booking, setBooking] =
    useState(null)

  const [secondsLeft, setSecondsLeft] =
    useState(0)

  // ================================
  // LOCATION HIERARCHY
  // ================================

 

  // ================================
  // CITY STATIONS
  // ================================

  const cityStations = useMemo(() => {
    return stations.filter(
      (station) => station.city === selectedCity
    )
  }, [selectedCity])

  const filteredStations = useMemo(() => {
    const query = search.trim().toLowerCase()

    if (!query) {
      return cityStations
    }

    return cityStations.filter((station) =>
      station.name.toLowerCase().includes(query)
    )
  }, [cityStations, search])

  // ================================
  // SMART PICK
  // ================================

  const smartPick = useMemo(() => {
    const availableStations = cityStations.filter(
      (station) => station.availableSlots > 0
    )

    if (availableStations.length === 0) {
      return null
    }

    return [...availableStations].sort(
      (a, b) => b.smartScore - a.smartScore
    )[0]
  }, [cityStations])

  const alternativeStations = useMemo(() => {
    return cityStations
      .filter(
        (station) =>
          station.id !== smartPick?.id &&
          station.availableSlots > 0
      )
      .sort((a, b) => b.smartScore - a.smartScore)
      .slice(0, 2)
  }, [cityStations, smartPick])

  // ================================
  // LOCATION
  // ================================

  function handleLocation() {
    if (!navigator.geolocation) {
      setMessage(
        "Location is not supported by this browser."
      )
      return
    }

    setMessage("Finding nearby metro stations...")

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setUserLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        })

        setLocationEnabled(true)

        setMessage(
          "Location found. Nearby recommendations are ready."
        )
      },
      () => {
        setLocationEnabled(false)

        setMessage(
          "Location permission was not given. You can search manually."
        )
      }
    )
  }

  // ================================
  // LOCATION SELECTION
  // ================================

  function handleStateSelect(stateId) {
    setSelectedState(stateId)
    setSelectedCity("")
    setSelectedLocationStation("")
    setSearch("")
    setMessage("")
  }

  function handleCitySelect(cityId) {
    setSelectedCity(cityId)
    setSelectedLocationStation("")
    setSearch("")
    setMessage("")
  }

  function handleLocationStationSelect(stationId) {
    setSelectedLocationStation(stationId)

    const realStation = stations.find(
      (item) => item.id === stationId
    )

    if (realStation) {
      setSearch(realStation.name)
    }
  }

  // ================================
  // OPEN PARKING
  // ================================

  function openParking(station) {
    setSelectedStation(station)
    setSelectedSlot(null)
    setMessage("")

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    })
  }

  function closeParking() {
    setSelectedStation(null)
    setSelectedSlot(null)
    setMessage("")
  }

  // ================================
  // PARKING SLOTS
  // ================================

  const parkingSlots = useMemo(() => {
    if (!selectedStation) {
      return []
    }

    const totalSlots = Math.min(
      selectedStation.totalSlots,
      60
    )

    const availableSlots = Math.min(
      selectedStation.availableSlots,
      totalSlots
    )

    return Array.from(
      { length: totalSlots },
      (_, index) => {
        const number = index + 1

        return {
          id: `P-${String(number).padStart(2, "0")}`,
          available: number <= availableSlots,
        }
      }
    )
  }, [selectedStation])

  // ================================
  // BOOKING
  // ================================

  function handleBookSlot() {
    if (!selectedStation || !selectedSlot) {
      return
    }

    const bookingId =
      "SPM-" +
      Math.random()
        .toString(36)
        .substring(2, 8)
        .toUpperCase()

    setBooking({
      id: bookingId,
      station: selectedStation.name,
      slot: selectedSlot.id,
      city: selectedCity,
    })

    setSecondsLeft(15 * 60)
    setSelectedSlot(null)

    setMessage(
      "Your slot is held for 15 minutes."
    )
  }

  // ================================
  // 15 MINUTE TIMER
  // ================================

  useEffect(() => {
    if (!booking || secondsLeft <= 0) {
      return undefined
    }

    const timer = setTimeout(() => {
      if (secondsLeft === 1) {
        setBooking(null)
        setSecondsLeft(0)
        setMessage(
          "Your 15-minute parking hold expired."
        )
      } else {
        setSecondsLeft(
          (previous) => previous - 1
        )
      }
    }, 1000)

    return () => clearTimeout(timer)
  }, [booking, secondsLeft])

  function cancelBooking() {
    setBooking(null)
    setSecondsLeft(0)
    setMessage(
      "Your parking hold has been cancelled."
    )
  }

  const minutes = String(
    Math.floor(secondsLeft / 60)
  ).padStart(2, "0")

  const seconds = String(
    secondsLeft % 60
  ).padStart(2, "0")

  // ================================
  // BOOKING SCREEN
  // ================================

  if (booking) {
    return (
      <div className="min-h-screen bg-[#F7F9FC] pb-24 text-[#102A43]">
        <Header />

        <main className="mx-auto max-w-md px-5 py-6">
          <button
            type="button"
            onClick={cancelBooking}
            className="mb-6 flex items-center gap-2 text-sm font-semibold text-[#607D9A]"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </button>

          <div className="rounded-3xl bg-white p-6 text-center shadow-sm">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[#E9F8F1]">
              <CheckCircle2 className="h-8 w-8 text-[#10A66F]" />
            </div>

            <h1 className="mt-5 text-2xl font-bold">
              Parking Held!
            </h1>

            <p className="mt-2 text-sm text-[#607D9A]">
              Reach the parking facility before the
              timer expires.
            </p>

            <div className="mt-6 rounded-2xl bg-[#102A43] p-5 text-white">
              <p className="text-xs text-slate-300">
                ARRIVAL WINDOW
              </p>

              <div className="mt-2 flex items-center justify-center gap-2">
                <Timer className="h-5 w-5 text-[#31E7A7]" />

                <span className="text-3xl font-bold">
                  {minutes}:{seconds}
                </span>
              </div>
            </div>

            <div className="mt-5 rounded-2xl bg-[#F7F9FC] p-4 text-left">
              <p className="text-xs text-[#607D9A]">
                METRO STATION
              </p>

              <p className="mt-1 font-bold">
                {booking.station}
              </p>

              <div className="mt-4 grid grid-cols-2 gap-3">
                <div>
                  <p className="text-xs text-[#607D9A]">
                    SLOT
                  </p>

                  <p className="mt-1 font-bold text-[#10A66F]">
                    {booking.slot}
                  </p>
                </div>

                <div>
                  <p className="text-xs text-[#607D9A]">
                    BOOKING ID
                  </p>

                  <p className="mt-1 font-bold">
                    {booking.id}
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-center">
              <div className="rounded-2xl border border-slate-100 bg-white p-4 shadow-sm">
                <QRCodeSVG
                  value={JSON.stringify(booking)}
                  size={170}
                  level="M"
                />
              </div>
            </div>

            <div className="mt-3 flex items-center justify-center gap-2 text-sm text-[#607D9A]">
              <QrCode className="h-4 w-4" />
              Scan at parking entry
            </div>

            <button
              type="button"
              onClick={cancelBooking}
              className="mt-6 w-full rounded-2xl border border-slate-200 px-5 py-3 text-sm font-bold"
            >
              Cancel Hold
            </button>
          </div>
        </main>

        <BottomNav
          active="bookings"
          onChange={setActiveNav}
        />
      </div>
    )
  }

  // ================================
  // PARKING DETAILS
  // ================================

  if (selectedStation) {
    return (
      <div className="min-h-screen bg-[#F7F9FC] pb-24 text-[#102A43]">
        <Header />

        <main className="mx-auto max-w-4xl px-5 py-6 lg:py-10">
          <button
            type="button"
            onClick={closeParking}
            className="mb-6 flex items-center gap-2 text-sm font-semibold text-[#607D9A]"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to stations
          </button>

          <section className="rounded-3xl bg-[#102A43] p-6 text-white">
            <div className="flex items-start justify-between">
              <div>
                <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-xs font-bold">
                  <Sparkles className="h-3.5 w-3.5" />
                  SmartPick {selectedStation.smartScore}
                </span>

                <h1 className="mt-4 text-2xl font-bold">
                  {selectedStation.name}
                </h1>

                <p className="mt-2 text-sm text-slate-300">
                  {selectedCity} Metro
                </p>
              </div>

              <ParkingSquare className="h-8 w-8 text-[#31E7A7]" />
            </div>

            <div className="mt-6 grid grid-cols-3 gap-3">
              <div className="rounded-2xl bg-white/10 p-3">
                <Car className="h-4 w-4 text-[#31E7A7]" />

                <p className="mt-2 text-lg font-bold">
                  {selectedStation.availableSlots}
                </p>

                <p className="text-xs text-slate-300">
                  Available
                </p>
              </div>

              <div className="rounded-2xl bg-white/10 p-3">
                <MapPin className="h-4 w-4 text-[#31E7A7]" />

                <p className="mt-2 text-lg font-bold">
                  {selectedStation.distance}
                </p>

                <p className="text-xs text-slate-300">
                  km
                </p>
              </div>

              <div className="rounded-2xl bg-white/10 p-3">
                <Clock3 className="h-4 w-4 text-[#31E7A7]" />

                <p className="mt-2 text-lg font-bold">
                  {selectedStation.driveTime}
                </p>

                <p className="text-xs text-slate-300">
                  min
                </p>
              </div>
            </div>
          </section>

          <section className="mt-8">
            <h2 className="text-xl font-bold">
              Choose your parking slot
            </h2>

            <p className="mt-1 text-sm text-[#607D9A]">
              Green = available · Grey = occupied
            </p>

            <div className="mt-5 grid grid-cols-4 gap-3 sm:grid-cols-6 lg:grid-cols-8">
              {parkingSlots.map((slot) => {
                const selected =
                  selectedSlot?.id === slot.id

                return (
                  <button
                    key={slot.id}
                    type="button"
                    disabled={!slot.available}
                    onClick={() =>
                      setSelectedSlot(slot)
                    }
                    className={`aspect-square rounded-2xl border text-sm font-bold transition ${
                      !slot.available
                        ? "cursor-not-allowed border-slate-100 bg-slate-100 text-slate-300"
                        : selected
                        ? "border-[#10A66F] bg-[#10A66F] text-white"
                        : "border-slate-200 bg-white text-[#102A43] hover:border-[#10A66F]"
                    }`}
                  >
                    {slot.id}
                  </button>
                )
              })}
            </div>
          </section>

          <section className="mt-8 rounded-3xl bg-white p-5 shadow-sm">
            <div className="flex gap-3">
              <Timer className="h-5 w-5 shrink-0 text-[#10A66F]" />

              <div>
                <h3 className="font-bold">
                  15-minute arrival hold
                </h3>

                <p className="mt-1 text-sm leading-6 text-[#607D9A]">
                  Your selected slot is held for
                  15 minutes. If you don't arrive,
                  it becomes available again.
                </p>
              </div>
            </div>
          </section>

          <button
            type="button"
            disabled={!selectedSlot}
            onClick={handleBookSlot}
            className={`mt-6 w-full rounded-2xl px-5 py-4 text-sm font-bold ${
              selectedSlot
                ? "bg-[#10A66F] text-white"
                : "cursor-not-allowed bg-slate-200 text-slate-400"
            }`}
          >
            {selectedSlot
              ? `Hold ${selectedSlot.id} for 15 minutes`
              : "Select a parking slot"}
          </button>
        </main>

        <BottomNav
          active={activeNav}
          onChange={setActiveNav}
        />
      </div>
    )
  }

  // ================================
  // MAIN HOME
  // ================================

  return (
    <div className="min-h-screen bg-[#F7F9FC] pb-24 text-[#102A43] lg:pb-0">
      <Header />

      <main className="mx-auto w-full max-w-7xl px-5 py-6 sm:px-8 lg:px-10 lg:py-10">

        {/* METRO BANNER */}
        <section className="metro-banner">
          <img
            src="/metro-hero.png"
            alt="Metro city"
            className="metro-banner-image"
          />

          <div className="metro-banner-overlay" />

          <div className="metro-banner-content">
            <span className="metro-banner-badge">
              <span className="hero-badge-dot" />
              SMART PARKING
            </span>

            <h1>
              Park smarter.
              <br />
              <span>Ride easier.</span>
            </h1>

            <p>
              Find parking near your metro station
              before you arrive.
            </p>
          </div>
        </section>

        {/* SEARCH */}
        <section className="search-panel-section">
          <div className="search-panel">
            <div className="search-input-wrap">
              <Search className="search-panel-icon" />

              <input
                type="text"
                value={search}
                onChange={(event) =>
                  setSearch(event.target.value)
                }
                placeholder="Where are you going?"
                className="search-panel-input"
              />

              {search && (
                <button
                  type="button"
                  onClick={() => setSearch("")}
                  className="search-clear"
                  aria-label="Clear search"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>

            <button
              type="button"
              onClick={handleLocation}
              className={`location-button ${
                locationEnabled
                  ? "location-active"
                  : ""
              }`}
            >
              <Navigation className="h-4 w-4" />

              <span>
                {locationEnabled
                  ? "Location On"
                  : "Use My Location"}
              </span>
            </button>
          </div>

          {message && (
            <div className="location-message">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{message}</span>
            </div>
          )}
        </section>

      {/* LOCATION HIERARCHY */}

<LocationSelector
  locationData={locationData}
  selectedState={selectedState}
  selectedCity={selectedCity}
  selectedLocationStation={selectedLocationStation}
  onStateSelect={handleStateSelect}
  onCitySelect={handleCitySelect}
  onStationSelect={handleLocationStationSelect}
/>
        {/* SMART PICK */}
        {smartPick && !search && (
          <section className="mt-8">
            <div className="mb-3 flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-[#10A66F]" />

              <h2 className="text-lg font-bold">
                SmartPick for you
              </h2>
            </div>

            <div className="rounded-3xl bg-[#102A43] p-6 text-white shadow-lg">
              <div className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-xs font-bold">
                <Sparkles className="h-3.5 w-3.5" />
                Best Match · {smartPick.smartScore}/100
              </div>

              <h3 className="mt-4 text-2xl font-bold">
                {smartPick.name}
              </h3>

              <p className="mt-2 text-sm leading-6 text-slate-300">
                Recommended using availability,
                distance and parking demand.
              </p>

              <div className="mt-5 flex flex-wrap gap-4 text-sm text-slate-200">
                <span className="flex items-center gap-1.5">
                  <MapPin className="h-4 w-4" />
                  {smartPick.distance} km
                </span>

                <span className="flex items-center gap-1.5">
                  <Clock3 className="h-4 w-4" />
                  {smartPick.driveTime} min
                </span>

                <span className="flex items-center gap-1.5">
                  <Car className="h-4 w-4" />
                  {smartPick.availableSlots} free
                </span>
              </div>

              <button
                type="button"
                onClick={() =>
                  openParking(smartPick)
                }
                className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#10A66F] px-5 py-3.5 text-sm font-bold sm:w-auto"
              >
                View Parking
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </section>
        )}

        {/* STATIONS */}
        <section className="mt-10">
          <div className="mb-4">
            <h2 className="text-xl font-bold">
              Metro parking
            </h2>

            <p className="mt-1 text-sm text-[#607D9A]">
              {filteredStations.length} station
              {filteredStations.length !== 1
                ? "s"
                : ""}{" "}
              available in {selectedCity}
            </p>
          </div>

          {filteredStations.length > 0 ? (
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {filteredStations.map(
                (station) => (
                  <StationCard
                    key={station.id}
                    station={station}
                    onView={openParking}
                  />
                )
              )}
            </div>
          ) : (
            <div className="rounded-3xl bg-white p-10 text-center shadow-sm">
              <MapPin className="mx-auto h-10 w-10 text-slate-300" />

              <h3 className="mt-4 font-bold">
                No station found
              </h3>

              <p className="mt-2 text-sm text-[#607D9A]">
                Try searching for another station.
              </p>

              <button
                type="button"
                onClick={() => setSearch("")}
                className="mt-5 rounded-xl bg-[#10A66F] px-5 py-2.5 text-sm font-bold text-white"
              >
                Show all stations
              </button>
            </div>
          )}
        </section>

        {/* PREDICTION */}
        {smartPick && (
          <section className="mt-8 rounded-3xl bg-white p-5 shadow-sm">
            <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-[#10A66F]" />

                  <h2 className="font-bold">
                    Parking prediction
                  </h2>
                </div>

                <p className="mt-2 max-w-xl text-sm leading-6 text-[#607D9A]">
                  Expected parking occupancy at{" "}
                  {smartPick.name}.
                </p>
              </div>

              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className="text-3xl font-bold">
                    {smartPick.prediction}%
                  </p>

                  <p className="text-xs text-[#607D9A]">
                    predicted occupancy
                  </p>
                </div>

                <div className="h-3 w-24 overflow-hidden rounded-full bg-slate-100">
                  <div
                    className="h-full rounded-full bg-[#10A66F]"
                    style={{
                      width: `${smartPick.prediction}%`,
                    }}
                  />
                </div>
              </div>
            </div>
          </section>
        )}

        {/* STATION INTELLIGENCE */}
        {smartPick && (
          <section className="mt-8 grid gap-4 lg:grid-cols-3">
            <div className="rounded-3xl border border-amber-100 bg-amber-50 p-5">
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white">
                  <AlertCircle className="h-5 w-5 text-amber-600" />
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-wide text-amber-700">
                    Rush alert
                  </p>
                  <h3 className="mt-1 font-bold text-metro-navy">
                    {smartPick.prediction >= 80
                      ? "High demand expected"
                      : "Parking demand looks manageable"}
                  </h3>
                  <p className="mt-1 text-sm leading-5 text-slate-600">
                    {smartPick.prediction >= 80
                      ? `${smartPick.prediction}% predicted occupancy at ${smartPick.name}.`
                      : `Current prediction is ${smartPick.prediction}% occupancy at ${smartPick.name}.`}
                  </p>
                </div>
              </div>
            </div>

            <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-smart-green-light">
                  <Clock3 className="h-5 w-5 text-smart-green" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-bold uppercase tracking-wide text-smart-green">
                    Metro timing
                  </p>
                  <h3 className="mt-1 font-bold text-metro-navy">
                    Next metro in ~6 min
                  </h3>
                  <p className="mt-1 text-sm text-slate-500">
                    Timing preview for the selected station.
                  </p>
                </div>
              </div>
            </div>

            <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-smart-green-light">
                  <Navigation className="h-5 w-5 text-smart-green" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-bold uppercase tracking-wide text-smart-green">
                    Parking guidance
                  </p>
                  <h3 className="mt-1 font-bold text-metro-navy">
                    Navigate to parking
                  </h3>
                  <p className="mt-1 text-sm text-slate-500">
                    Open directions to the recommended station.
                  </p>
                  <button
                    type="button"
                    onClick={() =>
                      window.open(
                        `https://www.google.com/maps/dir/?api=1&destination=${smartPick.latitude},${smartPick.longitude}`,
                        "_blank",
                        "noopener,noreferrer"
                      )
                    }
                    className="mt-3 rounded-xl bg-smart-green px-4 py-2.5 text-xs font-bold text-white hover:bg-smart-green-dark"
                  >
                    Open Google Maps
                  </button>
                </div>
              </div>
            </div>
          </section>
        )}

        {alternativeStations.length > 0 && (
          <section className="mt-8 rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-bold uppercase tracking-wide text-smart-green">
                  Backup recommendation
                </p>
                <h2 className="mt-1 text-lg font-bold text-metro-navy">
                  If your first choice gets busy
                </h2>
                <p className="mt-1 text-sm text-slate-500">
                  Smart alternatives with available parking.
                </p>
              </div>
              <Sparkles className="h-5 w-5 shrink-0 text-smart-green" />
            </div>

            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              {alternativeStations.map((station) => (
                <button
                  key={station.id}
                  type="button"
                  onClick={() => openParking(station)}
                  className="flex items-center justify-between rounded-2xl border border-slate-200 p-4 text-left transition hover:border-smart-green hover:bg-slate-50"
                >
                  <div className="min-w-0">
                    <p className="truncate font-bold text-metro-navy">
                      {station.name}
                    </p>
                    <p className="mt-1 text-xs text-slate-500">
                      {station.availableSlots} slots · {station.distance} km · Score {station.smartScore}
                    </p>
                  </div>
                  <ChevronRight className="h-5 w-5 shrink-0 text-smart-green" />
                </button>
              ))}
            </div>
          </section>
        )}

        {/* LOCATION STATUS */}
        {userLocation && (
          <section className="mt-6 rounded-2xl border border-[#DCEFE5] bg-[#E9F8F1] p-4">
            <div className="flex gap-3">
              <Navigation className="h-5 w-5 shrink-0 text-[#10A66F]" />

              <div>
                <p className="text-sm font-bold">
                  Location tracking active
                </p>

                <p className="mt-1 text-xs text-[#607D9A]">
                  Your location can be used to find
                  nearby metro parking.
                </p>
              </div>
            </div>
          </section>
        )}
      </main>

      <BottomNav
        active={activeNav}
        onChange={setActiveNav}
      />
    </div>
  )
}

export default Home