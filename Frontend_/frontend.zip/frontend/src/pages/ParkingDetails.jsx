import { useState } from "react";
import { ArrowLeft, Car, CheckCircle2, Clock3 } from "lucide-react";

function ParkingDetails({ station, onBack }) {
  const [selectedSlot, setSelectedSlot] = useState(null);

  const slots = [
    { id: "A01", status: "available" },
    { id: "A02", status: "available" },
    { id: "A03", status: "occupied" },
    { id: "A04", status: "available" },
    { id: "A05", status: "occupied" },
    { id: "A06", status: "available" },
    { id: "B01", status: "available" },
    { id: "B02", status: "occupied" },
    { id: "B03", status: "available" },
    { id: "B04", status: "available" },
    { id: "B05", status: "occupied" },
    { id: "B06", status: "available" },
  ];

  const availableSlots = slots.filter(
    (slot) => slot.status === "available"
  ).length;

  return (
    <div className="min-h-screen bg-slate-50 pb-10">
      <div className="max-w-6xl mx-auto px-5 py-6">

        {/* Back */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-slate-600 hover:text-slate-900 mb-6"
        >
          <ArrowLeft className="w-5 h-5" />
          Back
        </button>

        {/* Header */}
        <div className="bg-metro-navy text-white rounded-3xl p-6 mb-6">
          <p className="text-green-300 text-sm font-medium">
            Metro Parking
          </p>

          <h1 className="text-3xl font-bold mt-1">
            {station?.name || "Metro Station"}
          </h1>

          <div className="flex flex-wrap gap-5 mt-4 text-sm text-slate-200">
            <span className="flex items-center gap-2">
              <Car className="w-4 h-4" />
              {availableSlots} slots available
            </span>

            <span className="flex items-center gap-2">
              <Clock3 className="w-4 h-4" />
              15 min reservation
            </span>
          </div>
        </div>

        {/* Availability */}
        <div className="bg-white rounded-2xl p-5 shadow-sm mb-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-xl font-bold text-metro-navy">
                Parking Availability
              </h2>

              <p className="text-slate-500 mt-1">
                Select an available parking slot
              </p>
            </div>

            <div className="text-right">
              <p className="text-3xl font-bold text-smart-green">
                {availableSlots}
              </p>

              <p className="text-sm text-slate-500">
                available
              </p>
            </div>
          </div>
        </div>

        {/* Legend */}
        <div className="flex gap-5 mb-4 text-sm">
          <span className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-smart-green"></span>
            Available
          </span>

          <span className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-slate-400"></span>
            Occupied
          </span>
        </div>

        {/* Slots */}
        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <h2 className="text-lg font-bold text-metro-navy mb-5">
            Parking Slots
          </h2>

          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
            {slots.map((slot) => {
              const available = slot.status === "available";
              const selected = selectedSlot === slot.id;

              return (
                <button
                  key={slot.id}
                  disabled={!available}
                  onClick={() => setSelectedSlot(slot.id)}
                  className={`
                    rounded-xl p-4 text-center border-2 transition
                    ${
                      !available
                        ? "bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed"
                        : selected
                        ? "bg-green-50 border-smart-green text-smart-green"
                        : "bg-white border-green-200 text-metro-navy hover:border-smart-green"
                    }
                  `}
                >
                  <div className="font-bold">
                    {slot.id}
                  </div>

                  <div className="text-xs mt-1">
                    {available ? "Available" : "Occupied"}
                  </div>

                  {selected && (
                    <CheckCircle2 className="w-5 h-5 mx-auto mt-2" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Booking */}
        {selectedSlot && (
          <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg p-4">
            <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
              <div>
                <p className="text-sm text-slate-500">
                  Selected slot
                </p>

                <p className="font-bold text-metro-navy text-lg">
                  {selectedSlot}
                </p>
              </div>

              <button
                className="bg-smart-green text-white px-7 py-3 rounded-xl font-semibold hover:opacity-90"
                onClick={() =>
                  alert(
                    `Slot ${selectedSlot} selected. Booking will be connected to the backend next.`
                  )
                }
              >
                Book Slot
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default ParkingDetails;