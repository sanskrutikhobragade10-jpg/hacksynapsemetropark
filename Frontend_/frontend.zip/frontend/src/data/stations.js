export const cities = [
  {
    id: "nagpur",
    name: "Nagpur",
    status: "Operational",
  },
  {
    id: "bhopal",
    name: "Bhopal",
    status: "Operational",
  },
  {
    id: "indore",
    name: "Indore",
    status: "Expansion",
  },
]

export const stations = [
  // =========================
  // NAGPUR
  // =========================

  {
    id: "sitabuldi",
    city: "nagpur",
    name: "Sitabuldi Metro",
    distance: 0.8,
    driveTime: 3,
    walkTime: 5,
    totalSlots: 200,
    availableSlots: 124,
    occupancy: 38,
    prediction: 85,
    status: "available",
    smartScore: 96,
    latitude: 21.1458,
    longitude: 79.0882,
  },

  {
    id: "dharampeth",
    city: "nagpur",
    name: "Dharampeth Metro",
    distance: 1.8,
    driveTime: 6,
    walkTime: 4,
    totalSlots: 120,
    availableSlots: 46,
    occupancy: 62,
    prediction: 68,
    status: "available",
    smartScore: 92,
    latitude: 21.137,
    longitude: 79.066,
  },

  {
    id: "airport",
    city: "nagpur",
    name: "Airport Metro",
    distance: 4.1,
    driveTime: 10,
    walkTime: 6,
    totalSlots: 150,
    availableSlots: 18,
    occupancy: 88,
    prediction: 94,
    status: "available",
    smartScore: 71,
    latitude: 21.0922,
    longitude: 79.0472,
  },

  // =========================
  // BHOPAL
  // =========================

  {
    id: "mp-nagar",
    city: "bhopal",
    name: "MP Nagar Metro",
    distance: 1.2,
    driveTime: 5,
    walkTime: 4,
    totalSlots: 180,
    availableSlots: 72,
    occupancy: 60,
    prediction: 78,
    status: "available",
    smartScore: 94,
    latitude: 23.2156,
    longitude: 77.434,
  },

  {
    id: "rani-kamlapati",
    city: "bhopal",
    name: "Rani Kamlapati Metro",
    distance: 2.4,
    driveTime: 7,
    walkTime: 6,
    totalSlots: 220,
    availableSlots: 95,
    occupancy: 57,
    prediction: 70,
    status: "available",
    smartScore: 89,
    latitude: 23.2294,
    longitude: 77.4347,
  },

  {
    id: "aiims-bhopal",
    city: "bhopal",
    name: "AIIMS Metro",
    distance: 4.2,
    driveTime: 11,
    walkTime: 7,
    totalSlots: 150,
    availableSlots: 32,
    occupancy: 79,
    prediction: 91,
    status: "available",
    smartScore: 74,
    latitude: 23.2599,
    longitude: 77.4332,
  },

  // =========================
  // INDORE
  // =========================

  {
    id: "super-corridor",
    city: "indore",
    name: "Super Corridor Metro",
    distance: 2.1,
    driveTime: 7,
    walkTime: 5,
    totalSlots: 160,
    availableSlots: 84,
    occupancy: 48,
    prediction: 65,
    status: "available",
    smartScore: 93,
    latitude: 22.7196,
    longitude: 75.8577,
  },

  {
    id: "gandhi-nagar",
    city: "indore",
    name: "Gandhi Nagar Metro",
    distance: 3.4,
    driveTime: 10,
    walkTime: 6,
    totalSlots: 140,
    availableSlots: 52,
    occupancy: 63,
    prediction: 81,
    status: "available",
    smartScore: 82,
    latitude: 22.751,
    longitude: 75.801,
  },
]