export const locationData = [
  {
    stateId: "maharashtra",
    stateName: "Maharashtra",

    cities: [
      {
        cityId: "nagpur",
        cityName: "Nagpur",

        metros: [
          {
            metroId: "nagpur-metro",
            metroName: "Nagpur Metro",

            stations: [
              {
                stationId: "sitabuldi",
                stationName: "Sitabuldi Metro",
              },
              {
                stationId: "dharampeth",
                stationName: "Dharampeth Metro",
              },
              {
                stationId: "airport",
                stationName: "Airport Metro",
              },
            ],
          },
        ],
      },
    ],
  },

  {
    stateId: "madhya-pradesh",
    stateName: "Madhya Pradesh",

    cities: [
      {
        cityId: "bhopal",
        cityName: "Bhopal",

        metros: [
          {
            metroId: "bhopal-metro",
            metroName: "Bhopal Metro",

            stations: [
              {
                stationId: "mp-nagar",
                stationName: "MP Nagar Metro",
              },
              {
                stationId: "rani-kamlapati",
                stationName: "Rani Kamlapati Metro",
              },
              {
                stationId: "aiims-bhopal",
                stationName: "AIIMS Metro",
              },
            ],
          },
        ],
      },

      {
        cityId: "indore",
        cityName: "Indore",

        metros: [
          {
            metroId: "indore-metro",
            metroName: "Indore Metro",

            stations: [
              {
                stationId: "super-corridor",
                stationName: "Super Corridor Metro",
              },
              {
                stationId: "gandhi-nagar",
                stationName: "Gandhi Nagar Metro",
              },
            ],
          },
        ],
      },
    ],
  },
]