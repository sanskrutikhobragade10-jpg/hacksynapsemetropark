import { useState } from "react"
import Home from "./pages/Home"
import ParkingDetails from "./pages/ParkingDetails"
import MetroSplash from "./components/MetroSplash"

function App() {
  const [showSplash, setShowSplash] = useState(true)
  const [page, setPage] = useState("home")
  const [selectedStation, setSelectedStation] = useState(null)

  const openParking = (station) => {
    setSelectedStation(station)
    setPage("parking")
  }

  const goHome = () => {
    setPage("home")
    setSelectedStation(null)
  }

  if (showSplash) {
    return <MetroSplash onComplete={() => setShowSplash(false)} />
  }

  if (page === "parking") {
    return (
      <ParkingDetails
        station={selectedStation}
        onBack={goHome}
      />
    )
  }

  return <Home onViewParking={openParking} />
}

export default App